# NFX
Nova Pheonix Package Manager (Python Local Module+Binary)
